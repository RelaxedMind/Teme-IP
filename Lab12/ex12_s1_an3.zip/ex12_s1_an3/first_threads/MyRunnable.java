
public class MyRunnable implements Runnable{
	public void run(){
		System.out.println("MyRunnable running");
	}
}
